<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('care_plan_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('care_plan_scheme_id')->constrained('care_plan_schemes')->onDelete('cascade');
            $table->string('question');
            $table->string('input_type');
            $table->string('screening')->nullable();
            $table->text('option')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('care_plan_questions');
    }
};
