<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();
            //basic info start
            $table->string('patient_id');
            $table->string('first_name');
            $table->string('slug');
            $table->string('last_name');
            $table->string('patient_image')->default('default_image.jpg');
            $table->string('gender');
            $table->string('dob');
            $table->string('age');
            $table->string('email')->nullable();
            $table->string('contact_no')->nullable();
            $table->string('address')->nullable();
            //basic info end
            //preference start
            $table->string('preferred_time')->nullable();
            $table->string('preferred_communication')->nullable();
            $table->string('preferred_language')->nullable();
            //preference end

            //patient detail start
            $table->foreignId('insurance_id')->nullable()->constrained('insurances');
            $table->foreignId('practice_id')->nullable()->constrained('practices');
            $table->foreignId('care_manager_id')->nullable()->constrained('users');
            $table->foreignId('doctor_id')->nullable()->constrained('users');
            $table->string('policy_no')->nullable();
            $table->boolean('enrol_in_ccm')->default(0);
            $table->string('ccm_enrol_date')->nullable();
            $table->string('ccm_type')->nullable();
            $table->boolean('enrol_in_rpm')->default(0);
            $table->string('rpm_enrol_date')->nullable();
            $table->string('consent')->nullable();
            $table->string('covid_status')->default('Unknown');
            $table->timestamp('last_checked')->nullable();
            $table->boolean('completed_call')->default(0);
            //patient detail end

            //other setting
            $table->boolean('allow_care_plan')->default(1);
            $table->boolean('allow_monthly_review')->default(0);
            $table->boolean('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
};
