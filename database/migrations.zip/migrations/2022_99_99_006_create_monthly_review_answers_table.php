<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('monthly_review_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('monthly_review_id')->constrained('monthly_reviews')->onDelete('cascade');
            $table->foreignId('monthly_review_question_id')->constrained('monthly_review_questions')->onDelete('cascade');
            $table->string('question');
            $table->string('answer')->nullable();
            $table->string('comment')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('monthly_review_answers');
    }
};
