<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('monthly_review_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('monthly_review_scheme_id')->constrained('monthly_review_schemes')->onDelete('cascade');
            $table->string('question');
            $table->string('input_type');
            $table->text('option')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('monthly_review_questions');
    }
};
