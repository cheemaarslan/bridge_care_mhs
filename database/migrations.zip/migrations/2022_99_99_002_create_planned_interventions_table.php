<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('planned_interventions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('chronic_condition_id')->constrained('chronic_conditions')->onDelete('cascade');
            $table->string('symptom');
            $table->text('planned_intervention');
            $table->text('person_responsible')->nullable();
            $table->string('time')->nullable();
            $table->string('desired_outcome')->nullable();
            $table->string('prognosis')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('planned_interventions');
    }
};
