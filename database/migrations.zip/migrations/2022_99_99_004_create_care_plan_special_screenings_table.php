<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('care_plan_special_screenings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('care_plan_id')->constrained('care_plans')->onDelete('cascade');
            $table->string('screening_name');
            $table->integer('points');
            $table->string('screening_description');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('care_plan_special_screenings');
    }
};
