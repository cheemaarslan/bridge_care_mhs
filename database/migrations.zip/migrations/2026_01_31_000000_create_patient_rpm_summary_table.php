<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Create a summary table for RPM patient metrics
        Schema::create('patient_rpm_summary', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('patient_id')->unique();

            // Averages
            $table->decimal('avg_sys', 10, 2)->nullable();
            $table->decimal('avg_dia', 10, 2)->nullable();
            $table->decimal('avg_pul', 10, 2)->nullable();

            // Last reading values
            $table->decimal('last_sys', 10, 2)->nullable();
            $table->decimal('last_dia', 10, 2)->nullable();
            $table->decimal('last_pul', 10, 2)->nullable();
            $table->timestamp('last_reading_time')->nullable();

            // Calculated fields
            $table->tinyInteger('category_order')->default(1);
            $table->tinyInteger('status_order')->default(1);

            // Time tracking
            $table->integer('total_minutes')->default(0);
            $table->integer('total_seconds')->default(0);
            $table->integer('days_with_reading_count')->default(0);

            $table->boolean('has_phone_call')->default(false);

            $table->timestamp('updated_at');

            // Indexes
            $table->index('patient_id');
            $table->index('category_order');
            $table->index('status_order');
            $table->index('last_reading_time');

            $table->foreign('patient_id')->references('id')->on('patients')->onDelete('cascade');
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_rpm_summary');
    }
};
