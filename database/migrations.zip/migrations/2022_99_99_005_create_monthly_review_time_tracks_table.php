<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('monthly_review_time_tracks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->onDelete('cascade');
            $table->foreignId('monthly_review_id')->constrained('monthly_reviews')->onDelete('cascade');
            $table->foreignId('monthly_review_scheme_id')->nullable()->constrained('monthly_review_schemes')->onDelete('cascade');
            $table->string('entry_type')->default('Automatic');
            $table->string('date')->default(Carbon::now());

            $table->integer('minutes')->nullable();
            $table->integer('seconds')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('monthly_review_time_tracks');
    }
};
